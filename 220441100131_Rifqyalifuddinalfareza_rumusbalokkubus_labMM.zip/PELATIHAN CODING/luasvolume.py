#Menghitung luas dan volumme kubus
print("Menghitung luas dan volume kubus")

r = int(input("Masukkan Rusuknya = "))

Luas = 6*r*r
Volume = r*r*r

print("Luas kubus adalah", Luas)
print("Volume Kubus adalah", Volume)



#Menghitung luas dan volume balok
print("Menghitung Luas dan Volume Balok")

panjang = int(input("Masukkan panjang = "))
lebar = int(input("Masukkan lebar = "))
tinggi = int(input("Masukkan tinggi = "))

luas = 2*(panjang*lebar)+(panjang*tinggi)+(lebar*tinggi)
volume = panjang*lebar*tinggi

print("Luas balok adalah", luas)
print("Volume balok adalah",volume)