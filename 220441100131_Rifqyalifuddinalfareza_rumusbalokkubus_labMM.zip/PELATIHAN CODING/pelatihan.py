nama = "Nama saya alfa"
angka = 13 
angka_pecahan = 1.5
tipe_boolean = True
tipe_list =("Budi, Arip, 12")
tipe_set = {1,2,2,3,3,4,5,6,6}
apengurangan = 5 - 2
woman = "nye" *3
pembagian = 30/10
pembagian_baru = 10//4
modulus = 10%8






print("Hallo", nama)
print("tipe int", angka_pecahan)
print("booelan :")
print(tipe_boolean)
print(tipe_list)
print(tipe_list[2])
print(tipe_set)
print(2+3)
print(2+3+5+7+9)
print(apengurangan)
print((woman) + "keterlaluan")
print("Hasilnya" , pembagian)
print(pembagian_baru)
print("modulusnya", modulus)

